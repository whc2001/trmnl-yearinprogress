# trmnl-yearinprogress

This plug-in shows the progress of the year (dots or bar) on [TRMNL device](https://usetrmnl.com/)

![dots option](https://raw.githubusercontent.com/monsieurm/trmnl-yearinprogress/refs/heads/main/trmnl-yearinprogress-dots.jpeg)
*dots option*

![dots option](https://raw.githubusercontent.com/monsieurm/trmnl-yearinprogress/refs/heads/main/trmnl-yearinprogress-bar.jpeg)
*bar option*

**Steps :**
 1. Import zip file in the [private plug-in page](https://usetrmnl.com/plugin_settings?keyname=private_plugin)
 2. Choose dots or bar option
 3. Save
